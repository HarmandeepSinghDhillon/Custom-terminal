from setuptools import setup, find_packages

setup(
    name="custom-terminal",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        'requests',
    ],
    entry_points={
        'console_scripts': [
            'cterm=custom_terminal.main:main',
        ],
    },
    author="Your Name",
    author_email="your.email@example.com",
    description="A custom terminal with weather command",
    license="MIT",
    keywords="terminal weather cli",
)